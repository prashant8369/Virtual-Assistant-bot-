# Virtual Assistant

### <b> Environment Setup: </b>

- Install Python 3.11.0 or (Any Higher Version).

- Run `pip install -r requirements.txt` inside terminal.

### <b>To Genenrate EXE file.</b>

- Run `generate-exe.ps1` file.

### <b>This is OpenSource Virtual Assistant so your contribution will be appreciated by many of users</b>
